#include <stdio.h>

int main(){
    printf("RULES: Create File Name At The Top Of The Code (.dmc/.txt File)");
}