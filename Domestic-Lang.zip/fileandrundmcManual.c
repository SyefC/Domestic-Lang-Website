#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <unistd.h>

char input[1024]; 
char show[1024];
char fname[1024];
char RUN[500];
char inputmenu[50];
char READFILE[100];
int n;
char done[25];

void runDMCLANGcode(){
    system("cls");
    system("color 0a");
    printf("-----------------------------------------------------------------------------------------------------------\n\n");
    printf("MAXIMUM FILE BYTES AND FILE CREATION LIMITED BY: 1KB AND 1 MINIMUM FILE CREATION AND 5 FILES MAXIMIMUM FILES CREATION\n");
    printf("\n-----------------------------------------------------------------------------------------------------------\n\n");
    printf("Which file would u run?\n"); 
FILE *READSFILE = fopen("FILENAME.dmcfl","r");
if(READSFILE == NULL){
    printf("File not found\n");
}
fgets(READFILE,100,READSFILE);
    FILE *f = fopen(READFILE,"r");
        if(f == NULL){
        printf("Error 01: File is empty or not found or have not been created yet. Or could be an unexpected error.\n");
    }
    while(fgets(input,1024,f) != NULL){
    input[strcspn(input,"\n")] = '\0';
     if(sscanf(input, "printline(\"%[^\"]\");" ,show) == 1){
        printf("%s\n",show);
        }
        if(sscanf(input,"loop(%d).thisfunction.=.printline(\"%[^\"]\");",&n,show) == 2){
            while(n > 0){
                printf("%s\n",show);
                n--;
            }
        }
    }
     
    fclose(f);
    fclose(READSFILE);
}
int main(){
for(int i = 10; i > 0; i--){
    system("cls");
    system("color C");
printf("!!!WARNING!!!\n: ADD .dmc (for Domestic Programming Language) or .txt (Text Based) IN THE BACK OF THE FILE NAME <----------!!!\n");
printf("------------------------------------------------------------------\n");
printf("To run Code Type Run/run\n");
printf("------------------------------------------------------------------\n");
printf("--%d Seconds Until Land To The Menu....\n",i);
printf("------------------------------------------------------------------\n");
printf("Press Any Key To Continue... (Press Any Key Only One Time Buffer Cant Handle)\n");
printf("------------------------------------------------------------------\n");
sleep(1);
if(kbhit()){
    i = 0;
    getch();
    system("cls");
}
}
system("color F");
FILE *bereadsfile = fopen(fname,"r");
fscanf(bereadsfile,"%s",fname);
printf("Choose beetween 1, 2 and 3\n");
printf("1.Make .dmc/.txt File\n");
printf("2.Run Code\n");
printf("3.My Files\n");
printf(": ");
fgets(inputmenu,50,stdin);
if(strcmp(inputmenu,"2\n") == 0){
    system("cls");
    system("color 0a");
    printf("Would You Like To Run Code?\n");
    printf("Type Run/run to run code\n");
    fgets(fname,1024,stdin);
    if(strcmp(fname,"run\n") == 0 || strcmp(fname,"Run\n") == 0){
        runDMCLANGcode();
    }
}
else if(strcmp(inputmenu,"1\n") == 0){
    printf("Add .dmc (For Domestic Lang) or .txt (For Text Based) to the end of the filename\n");
    printf("ENTER FILENAME:");
    fgets(fname,1024,stdin);
    fname[strcspn(fname,"\n")] = '\0';
    FILE *FILELIST = fopen("FILENAME.dmcfl","a");
    FILE *filename = fopen(fname,"a");
    fprintf(FILELIST,"%s",fname);
    FILE *readsfile = fopen(fname,"r");
    fprintf(filename,"%s","function list: printline(""); and loop([number]).thisfunction.=.printline("");");
    fscanf(readsfile,"%s",fname);
    fclose(filename);
    fclose(readsfile);
}
else if(strcmp(inputmenu,"3\0") == 0){
    printf("Files:\n");
    printf("1.%s",fname);
}
        return 0;
}